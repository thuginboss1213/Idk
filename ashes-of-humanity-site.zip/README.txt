ASHES OF HUMANITY - hosting
Upload this whole folder to any static host (all free):
 - Netlify Drop: drag the folder onto app.netlify.com/drop
 - Cloudflare Pages: Create project > Direct Upload
 - GitHub Pages: push the files to a repo, Settings > Pages
It must be served over HTTPS (all of the above are), which VR needs too.
Phone: open the link, then Add to Home Screen to install it fullscreen.
Quest: open the link in the Quest Browser and press Enter VR.
Note: accounts and saves are stored in each player's own browser. Real shared accounts and multiplayer need a backend.
